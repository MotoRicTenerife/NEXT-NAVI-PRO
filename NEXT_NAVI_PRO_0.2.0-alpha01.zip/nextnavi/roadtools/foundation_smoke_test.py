#!/usr/bin/env python3
"""Static regression checks for NEXT NAVI PRO alpha MVP. Not a substitute for Android build/device tests."""
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
main = (ROOT / 'app/src/main/java/com/nextnavipro/app/MainActivity.java').read_text()
manifest = (ROOT / 'app/src/main/AndroidManifest.xml').read_text()
checks = {
    'official splash image bundled': (ROOT / 'app/src/main/res/drawable-nodpi/next_navi_splash.png').exists(),
    'real fused location provider': 'FusedLocationProviderClient' in main and 'requestLocationUpdates' in main,
    'rejects stale GPS fixes': 'GPS OBSOLETO' in main and '10000L' in main,
    'rejects inaccurate GPS fixes': 'GPS INSUFFICIENTE' in main and 'getAccuracy()>50f' in main or 'getAccuracy() > 50f' in main,
    'portrait and landscape dashboard layouts': 'ORIENTATION_LANDSCAPE' in main and 'main.addView(speedPanel' in main,
    'MapLibre vector map is used': 'MapView' in main and 'MAP_STYLE' in main and 'tiles.openfreemap.org/styles/liberty' in main,
    'routing and turn instructions exist': 'router.project-osrm.org/route/v1/driving' in main and 'instructionFor(' in main,
    'automatic off-route rerouting exists': 'checkOffRoute()' in main and 'Fuori percorso · ricalcolo' in main,
    'OSM speed limits use a road engine': 'roadEngine.speedLimitKmh(l)' in main and 'DATI STRADALI NON DISPONIBILI' in main,
    'unknown limit remains unknown': 'limitValue.setText(matchedLimit>0?Integer.toString(matchedLimit):"—")' in main,
    'weather includes current and hourly data': 'api.open-meteo.com/v1/forecast' in main and 'PREVISIONI ORARIE' in main,
    'curve detection and audible alerts': 'findCurveOnRoute(l,pts)' in main and 'playCurveBeep(' in main and 'updateCurveDisplay(' in main,
    'persistent trip database and GPX export': 'tripDb.listTrips(100)' in main and 'buildGpx(long tripId)' in main and 'ACTION_CREATE_DOCUMENT' in main,
    'positive and negative themes persist': 'POSITIVO — sfondo scuro' in main and 'NEGATIVO — sfondo chiaro' in main and 'putBoolean(PREF_NEGATIVE, negativeTheme)' in main,
    'demo mode removed': 'DEMO' not in main and 'demoMode' not in main and 'renderDemo' not in main,
    'location and internet permissions declared': all(x in manifest for x in ('ACCESS_FINE_LOCATION','ACCESS_COARSE_LOCATION','INTERNET')),
    'new project has map and routing dependencies': "org.maplibre.gl:android-sdk-opengl:13.6.1" in (ROOT/'app/build.gradle').read_text(),
}
for name, passed in checks.items(): print(('PASS' if passed else 'FAIL') + '  ' + name)
if not all(checks.values()): raise SystemExit(1)
print(f'\n{len(checks)} static checks passed. Android compilation and on-device behavior are not tested by this script.')
