# Roadtools

Run `python3 foundation_smoke_test.py` from this directory or from the project root with `python3 roadtools/foundation_smoke_test.py`. The script performs static source checks only; it does not replace an Android build or device tests.
