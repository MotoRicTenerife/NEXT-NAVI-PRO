package com.nextnavipro.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.location.Location;
import android.os.Bundle;
import android.os.Looper;
import android.os.Handler;
import android.media.ToneGenerator;
import android.media.AudioManager;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.Priority;
import org.maplibre.android.MapLibre;
import org.maplibre.android.WellKnownTileServer;
import org.maplibre.android.camera.CameraPosition;
import org.maplibre.android.geometry.LatLng;
import org.maplibre.android.maps.MapLibreMap;
import org.maplibre.android.maps.MapView;
import org.maplibre.android.maps.Style;
import org.maplibre.android.annotations.MarkerOptions;
import org.maplibre.android.annotations.Marker;
import org.maplibre.android.style.layers.LineLayer;
import org.maplibre.android.style.sources.GeoJsonSource;
import org.maplibre.android.style.layers.PropertyFactory;
import org.maplibre.geojson.Feature;
import org.maplibre.geojson.LineString;
import org.maplibre.geojson.Point;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Date;
import java.util.TimeZone;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/** NEXT NAVI PRO: online field-test MVP. Real GPS only; route and weather data are never simulated. */
public class MainActivity extends Activity {
    private static final int REQUEST_LOCATION = 71;
    private static final String PREFS = "next_navi_preferences";
    private static final String PREF_NEGATIVE = "negative_theme";
    private static final String PREF_TRIPS = "trips_json";
    private static final String MAP_STYLE = "https://tiles.openfreemap.org/styles/liberty";
    private FusedLocationProviderClient fused;
    private LocationCallback locationCallback;
    private TextToSpeech tts;
    private TextView speedValue, gpsStatus, limitValue, limitNote, navInstruction, modeLabel, navSubLabel, curveWarningLabel;
    private boolean negativeTheme = false;
    private volatile boolean navigating = false;
    private boolean routeRequestInFlight = false;
    private float currentSpeedKmh = 0f;
    private volatile int currentSpeedLimitKmh = 0;
    private Location currentLocation;
    private String currentScreen = "dashboard", nextInstruction = "Navigazione non avviata";
    private float originalWindowBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE;
    private boolean brightnessCaptured = false;
    private MapView mapView;
    private MapLibreMap mapLibreMap;
    private Marker currentPositionMarker, destinationMarker;
    private Location lastCameraLocation;
    private float lastCameraBearing = Float.NaN;
    private long lastCameraUpdateMs = 0L;
    private long lastOffRouteCheckMs = 0L;
    private TextView navigatorStatus;
    private double destinationLat = Double.NaN, destinationLon = Double.NaN;
    private int offRouteCount = 0;
    private long lastRerouteMs = 0L;
    private int lastAnnouncedStepIndex = -1;
    private int lastAnnouncedStepStage = 0;
    private boolean arrivalAnnounced = false;
    private String lastCurveAlertKey = "";
    private long lastCurveBeepAt = 0L;
    private final Handler audioHandler = new Handler(Looper.getMainLooper());
    private ToneGenerator toneGenerator;
    static final class RoutePoint { final double lat,lon; RoutePoint(double a,double o){lat=a;lon=o;} }
    private JSONObject activeRoute;
    private volatile JSONArray routeCoordinates;
    private JSONArray routeSteps;
    private int nextStepIndex = 0;
    private long lastVoiceAt = 0L;
    private final ExecutorService roadExecutor = Executors.newSingleThreadExecutor();
    private final AtomicBoolean roadTaskQueued = new AtomicBoolean(false);
    private volatile Location latestRoadLocation;
    private RoadDb roadDb;
    private RoadEngine roadEngine;
    private long lastRoadFetchAt = 0L;
    private Location lastRoadFetchLocation;
    private TripDb tripDb;
    private TripRecorder tripRecorder;
    private long pendingExportTripId = -1L;
    private static final int REQUEST_EXPORT_GPX = 904;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        originalWindowBrightness = getWindow().getAttributes().screenBrightness;
        brightnessCaptured = true;
        negativeTheme = getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean(PREF_NEGATIVE, false);
        applySystemBars();
        MapLibre.getInstance(this, null, WellKnownTileServer.MapLibre);
        fused = LocationServices.getFusedLocationProviderClient(this);
        roadDb = new RoadDb(this); roadEngine = new RoadEngine(roadDb);
        tripDb = new TripDb(this); tripDb.recoverInterruptedTrips(System.currentTimeMillis()); tripRecorder = new TripRecorder(tripDb, null);
        lastRoadFetchAt=getSharedPreferences(PREFS,MODE_PRIVATE).getLong("roads_last_fetch",0L);
        String savedRoadLoc=getSharedPreferences(PREFS,MODE_PRIVATE).getString("roads_last_location","");
        try{if(savedRoadLoc.contains(",")){String[] xy=savedRoadLoc.split(",");lastRoadFetchLocation=new Location("cache");lastRoadFetchLocation.setLatitude(Double.parseDouble(xy[0]));lastRoadFetchLocation.setLongitude(Double.parseDouble(xy[1]));}}catch(Exception ignored){}
        tts = new TextToSpeech(this, status -> { if (status == TextToSpeech.SUCCESS) tts.setLanguage(Locale.ITALIAN); });
        try{toneGenerator=new ToneGenerator(AudioManager.STREAM_MUSIC,75);}catch(Exception ignored){}
        showSplash();
        getWindow().getDecorView().postDelayed(() -> { if (!isFinishing()) showDashboard(); }, 850L);
    }

    private int bg() { return negativeTheme ? Color.rgb(245,247,250) : Color.rgb(5,10,18); }
    private int panelColor() { return negativeTheme ? Color.WHITE : Color.rgb(16,26,42); }
    private int primaryText() { return negativeTheme ? Color.rgb(8,15,25) : Color.WHITE; }
    private int mutedText() { return negativeTheme ? Color.rgb(70,80,95) : Color.rgb(170,182,200); }
    private int accent() { return negativeTheme ? Color.rgb(160,95,0) : Color.rgb(255,212,0); }
    private int alert() { return Color.rgb(210,35,45); }
    private int success() { return negativeTheme ? Color.rgb(0,115,65) : Color.rgb(90,220,140); }

    private void applySystemBars() {
        getWindow().setStatusBarColor(bg()); getWindow().setNavigationBarColor(bg());
        int flags=View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
        if(negativeTheme&&android.os.Build.VERSION.SDK_INT>=23)flags|=View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
        if(negativeTheme&&android.os.Build.VERSION.SDK_INT>=26)flags|=View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        getWindow().getDecorView().setSystemUiVisibility(flags);
    }
    private void showSplash() {
        ImageView image = new ImageView(this); image.setImageResource(R.drawable.next_navi_splash);
        image.setScaleType(ImageView.ScaleType.FIT_CENTER); image.setBackgroundColor(Color.rgb(2,8,20)); setContentView(image);
    }

    private void showDashboard() {
        disposeMapView();
        currentScreen = "dashboard"; applySystemBars();
        boolean landscape = getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE;
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(bg()); root.setPadding(dp(8), dp(4), dp(8), dp(4));
        TextView title = text("NEXT NAVI PRO", 17, accent(), true); title.setGravity(Gravity.CENTER); root.addView(title, new LinearLayout.LayoutParams(-1, dp(25)));
        modeLabel = text("GPS REALE · TEMA " + (negativeTheme ? "NEGATIVO" : "POSITIVO"), 10, mutedText(), true); modeLabel.setGravity(Gravity.CENTER); root.addView(modeLabel, new LinearLayout.LayoutParams(-1, dp(17)));
        LinearLayout main = new LinearLayout(this); main.setGravity(Gravity.CENTER); main.setOrientation(landscape ? LinearLayout.HORIZONTAL : LinearLayout.VERTICAL);
        LinearLayout.LayoutParams mainParams = new LinearLayout.LayoutParams(-1, 0, 1f); mainParams.topMargin = dp(2); mainParams.bottomMargin = dp(2); root.addView(main, mainParams);
        LinearLayout navPanel = panel(); navPanel.setPadding(dp(7), dp(7), dp(7), dp(7)); navPanel.setGravity(Gravity.CENTER);
        TextView navTitle = text("PROSSIMA MANOVRA", 11, accent(), true); navTitle.setGravity(Gravity.CENTER);
        navInstruction = text(nextInstruction, landscape ? 17 : 16, primaryText(), true); navInstruction.setGravity(Gravity.CENTER);
        navSubLabel = text(navigating ? "NAVIGAZIONE ATTIVA" : "Apri NAVIGATORE per impostare la destinazione", 9, mutedText(), false); navSubLabel.setGravity(Gravity.CENTER);
        navPanel.addView(navTitle); addSpace(navPanel, 7); navPanel.addView(navInstruction); addSpace(navPanel, 5); curveWarningLabel=text("AVVISI CURVA IN ATTESA DATI",10,mutedText(),true);curveWarningLabel.setGravity(Gravity.CENTER);navPanel.addView(curveWarningLabel);addSpace(navPanel,5);navPanel.addView(navSubLabel);
        LinearLayout speedPanel = panel(); speedPanel.setPadding(dp(4), dp(4), dp(4), dp(4)); speedPanel.setGravity(Gravity.CENTER);
        TextView speedCaption = text("VELOCITÀ GPS", 12, mutedText(), true); speedCaption.setGravity(Gravity.CENTER);
        speedValue = text(currentLocation == null ? "—" : String.format(Locale.getDefault(), "%.0f", currentSpeedKmh), landscape ? 76 : 82, primaryText(), true); speedValue.setGravity(Gravity.CENTER); speedValue.setSingleLine(true);
        TextView unit = text("km/h", 16, accent(), true); unit.setGravity(Gravity.CENTER); gpsStatus = text("GPS IN ATTESA", 10, mutedText(), true); gpsStatus.setGravity(Gravity.CENTER);
        speedPanel.addView(speedCaption); speedPanel.addView(speedValue); speedPanel.addView(unit); addSpace(speedPanel, 5); speedPanel.addView(gpsStatus);
        LinearLayout limitPanel = panel(); limitPanel.setGravity(Gravity.CENTER); limitPanel.setPadding(dp(5), dp(8), dp(5), dp(8));
        TextView limitCaption = text("LIMITE", 12, mutedText(), true); limitCaption.setGravity(Gravity.CENTER); limitValue = text("—", landscape ? 44 : 40, accent(), true); limitValue.setGravity(Gravity.CENTER);
        limitNote = text("NON DISPONIBILE", 9, mutedText(), true); limitNote.setGravity(Gravity.CENTER); limitPanel.addView(limitCaption); addSpace(limitPanel, 4); limitPanel.addView(limitValue); addSpace(limitPanel, 4); limitPanel.addView(limitNote);
        if (landscape) { main.addView(navPanel, new LinearLayout.LayoutParams(0, -1, 1.05f)); main.addView(speedPanel, new LinearLayout.LayoutParams(0, -1, 1.5f)); main.addView(limitPanel, new LinearLayout.LayoutParams(0, -1, .72f)); }
        else { main.addView(limitPanel, new LinearLayout.LayoutParams(-1, 0, .72f)); main.addView(speedPanel, new LinearLayout.LayoutParams(-1, 0, 1.65f)); main.addView(navPanel, new LinearLayout.LayoutParams(-1, 0, 1f)); }
        LinearLayout buttons = new LinearLayout(this); buttons.setGravity(Gravity.CENTER);
        String[] labels = {"NAVIGATORE", "RIDE", "METEO", "VIAGGI", "IMPOSTAZIONI"};
        for (String label : labels) { Button b = button(label); LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(0, dp(46), 1f); bp.setMargins(dp(2), dp(2), dp(2), dp(2)); buttons.addView(b, bp); b.setOnClickListener(v -> handleAction(label)); }
        root.addView(buttons, new LinearLayout.LayoutParams(-1, dp(50))); setContentView(root); startLocationIfPermitted();
    }

    private void handleAction(String action) {
        switch (action) {
            case "NAVIGATORE": showNavigator(); break;
            case "RIDE": endNavigation(); nextInstruction = "Guida libera · nessuna destinazione"; if (navInstruction != null) navInstruction.setText(nextInstruction); Toast.makeText(this, "Modalità RIDE · GPS reale", Toast.LENGTH_SHORT).show(); break;
            case "METEO": showWeather(); break;
            case "VIAGGI": showTrips(); break;
            case "IMPOSTAZIONI": showSettings(); break;
        }
    }

    private void endNavigation(){navigating=false;activeRoute=null;routeCoordinates=null;routeSteps=null;nextStepIndex=0;lastAnnouncedStepIndex=-1;lastAnnouncedStepStage=0;arrivalAnnounced=false;destinationLat=Double.NaN;destinationLon=Double.NaN;nextInstruction="Navigazione terminata";if(mapLibreMap!=null){try{mapLibreMap.getStyle(style->{try{if(style.getLayer("route-line")!=null)style.removeLayer("route-line");if(style.getSource("route-source")!=null)style.removeSource("route-source");}catch(Exception ignored){}});if(destinationMarker!=null)mapLibreMap.removeMarker(destinationMarker);}catch(Exception ignored){}}destinationMarker=null;if(navSubLabel!=null)navSubLabel.setText("GUIDA LIBERA");}

    private void showSettings() {
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(12),dp(6),dp(12),dp(4));
        RadioGroup group = new RadioGroup(this); group.setOrientation(RadioGroup.VERTICAL); group.setPadding(dp(6), dp(4), dp(6), dp(4));
        RadioButton positive = new RadioButton(this); positive.setText("POSITIVO — sfondo scuro, testi chiari"); positive.setId(1); group.addView(positive);
        RadioButton negative = new RadioButton(this); negative.setText("NEGATIVO — sfondo chiaro, testi scuri"); negative.setId(2); group.addView(negative); group.check(negativeTheme ? 2 : 1);box.addView(group);
        SharedPreferences prefs=getSharedPreferences(PREFS,MODE_PRIVATE);CheckBox voice=new CheckBox(this);voice.setText("Indicazioni vocali turn-by-turn");voice.setTextColor(primaryText());voice.setChecked(prefs.getBoolean("voice_enabled",true));box.addView(voice);
        CheckBox curves=new CheckBox(this);curves.setText("Avvisi acustici delle curve");curves.setTextColor(primaryText());curves.setChecked(prefs.getBoolean("curve_sound_enabled",true));box.addView(curves);
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle("IMPOSTAZIONI").setView(box).setNegativeButton("ANNULLA", null).setPositiveButton("APPLICA", (d,w) -> {
            negativeTheme = group.getCheckedRadioButtonId() == 2;
            prefs.edit().putBoolean(PREF_NEGATIVE, negativeTheme).putBoolean("voice_enabled",voice.isChecked()).putBoolean("curve_sound_enabled",curves.isChecked()).apply();
            if ("navigator".equals(currentScreen)) showNavigator(); else showDashboard();
        }).create();
        dialog.show(); dialog.getButton(-1).setTextColor(accent()); dialog.getButton(-2).setTextColor(accent());
    }

    private void showNavigator() {
        disposeMapView();
        currentScreen = "navigator"; applySystemBars();
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(bg());
        LinearLayout top = new LinearLayout(this); top.setPadding(dp(6), dp(4), dp(6), dp(4)); top.setGravity(Gravity.CENTER_VERTICAL);
        EditText search = new EditText(this); search.setSingleLine(true); search.setTextColor(primaryText()); search.setHintTextColor(mutedText()); search.setHint("Indirizzo o località"); search.setTextSize(14); search.setHintTextColor(mutedText());
        top.addView(search, new LinearLayout.LayoutParams(0, dp(48), 1f)); Button find = button("CERCA"); top.addView(find, new LinearLayout.LayoutParams(dp(78), dp(46)));
        Button home = button("CASA"); top.addView(home, new LinearLayout.LayoutParams(dp(62), dp(46))); root.addView(top);
        mapView = new MapView(this); root.addView(mapView, new LinearLayout.LayoutParams(-1, 0, 1f)); mapView.onCreate(new Bundle()); mapView.onStart(); mapView.onResume();
        TextView attribution=text("© OpenStreetMap contributors · OpenFreeMap",9,mutedText(),false); attribution.setGravity(Gravity.END|Gravity.CENTER_VERTICAL); attribution.setPadding(dp(4),0,dp(8),0); root.addView(attribution,new LinearLayout.LayoutParams(-1,dp(18)));
        LinearLayout bottom = new LinearLayout(this); bottom.setPadding(dp(5), dp(4), dp(5), dp(4)); bottom.setGravity(Gravity.CENTER_VERTICAL);
        TextView status = text(navigating ? nextInstruction : "Scegli una destinazione e premi CERCA", 12, primaryText(), true); status.setGravity(Gravity.CENTER_VERTICAL); navigatorStatus=status;
        bottom.addView(status, new LinearLayout.LayoutParams(0, dp(50), 1f)); Button stop = button(navigating ? "STOP" : "RIDE"); bottom.addView(stop, new LinearLayout.LayoutParams(dp(78), dp(46))); Button back = button("DISPLAY"); bottom.addView(back, new LinearLayout.LayoutParams(dp(82), dp(46))); root.addView(bottom); setContentView(root);
        mapView.getMapAsync(map -> { mapLibreMap = map; map.setStyle(new Style.Builder().fromUri(MAP_STYLE), style -> { if (currentLocation != null) { LatLng here=new LatLng(currentLocation.getLatitude(),currentLocation.getLongitude()); map.setCameraPosition(new CameraPosition.Builder().target(here).zoom(14.5).build()); currentPositionMarker=map.addMarker(new MarkerOptions().position(here).title("Posizione GPS")); } if(Double.isFinite(destinationLat)&&Double.isFinite(destinationLon))destinationMarker=map.addMarker(new MarkerOptions().position(new LatLng(destinationLat,destinationLon)).title("Destinazione")); if (routeCoordinates != null) drawRoute(); }); });
        find.setOnClickListener(v -> { String query = search.getText().toString().trim(); if (!query.isEmpty()) { ((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(search.getWindowToken(), 0); geocodeAndRoute(query, status); } });
        home.setOnClickListener(v -> { String homeQuery = getPreferences(MODE_PRIVATE).getString("home_address", ""); if (homeQuery.isEmpty()) { new AlertDialog.Builder(this).setTitle("Imposta CASA").setMessage("Vuoi salvare la posizione GPS attuale come CASA?").setNegativeButton("ANNULLA", null).setPositiveButton("SALVA POSIZIONE", (d,w) -> { if (currentLocation != null) getPreferences(MODE_PRIVATE).edit().putString("home_address", currentLocation.getLatitude()+","+currentLocation.getLongitude()).apply(); Toast.makeText(this, "Posizione CASA salvata", Toast.LENGTH_SHORT).show(); }).show(); } else geocodeAndRoute(homeQuery, status); });
        stop.setOnClickListener(v -> { if (navigating) { endNavigation(); nextInstruction = "Navigazione terminata"; status.setText(nextInstruction); speak("Navigazione terminata"); } else { currentScreen = "dashboard"; showDashboard(); } });
        back.setOnClickListener(v -> showDashboard());
        if (navigating && !nextInstruction.isEmpty()) status.setText(nextInstruction);
    }

    private void geocodeAndRoute(String query, TextView status) {
        if (currentLocation == null) { status.setText("In attesa di una posizione GPS valida"); return; }
        status.setText("Ricerca destinazione…");
        new Thread(() -> { try {
            double lat, lon;
            if (query.matches("-?\\d+(\\.\\d+)?,-?\\d+(\\.\\d+)?")) { String[] p = query.split(","); lat = Double.parseDouble(p[0]); lon = Double.parseDouble(p[1]); }
            else { String encoded = URLEncoder.encode(query, "UTF-8"); String json = httpGet("https://nominatim.openstreetmap.org/search?format=jsonv2&limit=1&q="+encoded, "NEXT-NAVI-PRO/0.1 (Android navigation app)"); JSONArray results = new JSONArray(json); if (results.length() == 0) throw new Exception("Destinazione non trovata"); JSONObject first = results.getJSONObject(0); lat = first.getDouble("lat"); lon = first.getDouble("lon"); }
            final double dlat=lat, dlon=lon;
            String routeJson = httpGet(String.format(Locale.US, "https://router.project-osrm.org/route/v1/driving/%.6f,%.6f;%.6f,%.6f?overview=full&geometries=geojson&steps=true", currentLocation.getLongitude(), currentLocation.getLatitude(), dlon, dlat), "NEXT-NAVI-PRO/0.1");
            JSONObject response = new JSONObject(routeJson); if (!"Ok".equals(response.optString("code"))) throw new Exception("Percorso non disponibile"); JSONArray routes = response.getJSONArray("routes"); if (routes.length()==0) throw new Exception("Nessun percorso trovato"); JSONObject route = routes.getJSONObject(0);
            runOnUiThread(() -> { destinationLat=dlat; destinationLon=dlon; offRouteCount=0; lastRerouteMs=System.currentTimeMillis(); lastAnnouncedStepIndex=-1; lastAnnouncedStepStage=0; arrivalAnnounced=false; activeRoute=route; routeCoordinates=route.optJSONObject("geometry").optJSONArray("coordinates"); JSONArray legs=route.optJSONArray("legs"); routeSteps=legs!=null&&legs.length()>0?legs.optJSONObject(0).optJSONArray("steps"):new JSONArray(); nextStepIndex=0; navigating=true; status.setText("Percorso trovato · "+formatDistance(route.optDouble("distance"))+" · ETA "+formatDuration(route.optDouble("duration"))); nextInstruction="Percorso calcolato"; if (mapLibreMap!=null) { if(destinationMarker!=null)mapLibreMap.removeMarker(destinationMarker);destinationMarker=mapLibreMap.addMarker(new MarkerOptions().position(new LatLng(dlat,dlon)).title("Destinazione")); drawRoute(); mapLibreMap.animateCamera(org.maplibre.android.camera.CameraUpdateFactory.newLatLngZoom(new LatLng(currentLocation.getLatitude(),currentLocation.getLongitude()), 14.5)); } updateNextStep(); speak("Percorso calcolato. "+nextInstruction); });
        } catch (Exception ex) { runOnUiThread(() -> status.setText("Errore: "+safeMessage(ex))); } }).start();
    }

    private void drawRoute() {
        if (mapLibreMap == null || routeCoordinates == null) return;
        mapLibreMap.getStyle(style -> { try { List<Point> points = new ArrayList<>(); for (int i=0;i<routeCoordinates.length();i++) { JSONArray c=routeCoordinates.getJSONArray(i); points.add(Point.fromLngLat(c.getDouble(0),c.getDouble(1))); } if (points.size()<2) return; if (style.getSource("route-source")!=null) style.removeSource("route-source"); if (style.getLayer("route-line")!=null) style.removeLayer("route-line"); style.addSource(new GeoJsonSource("route-source", Feature.fromGeometry(LineString.fromLngLats(points)))); style.addLayer(new LineLayer("route-line","route-source").withProperties(PropertyFactory.lineColor(negativeTheme?"#174EA6":"#FFD400"),PropertyFactory.lineWidth(5f),PropertyFactory.lineOpacity(.9f))); } catch (Exception ignored) {} });
    }

    private void updateNextStep() {
        if (!navigating || routeSteps == null || currentLocation == null) return;
        if (nextStepIndex == 0 && routeSteps.length() > 1) nextStepIndex = 1; // OSRM step 0 is normally the departure instruction.
        if (nextStepIndex >= routeSteps.length()) { nextInstruction="Sei arrivato a destinazione"; navigating=false; speak(nextInstruction); return; }
        try {
            JSONObject step=routeSteps.getJSONObject(nextStepIndex); JSONObject maneuver=step.optJSONObject("maneuver");
            JSONArray loc=maneuver==null?null:maneuver.optJSONArray("location");
            double distanceToManeuver=Double.POSITIVE_INFINITY;
            if(loc!=null&&loc.length()>=2){float[] result=new float[1];Location.distanceBetween(currentLocation.getLatitude(),currentLocation.getLongitude(),loc.getDouble(1),loc.getDouble(0),result);distanceToManeuver=result[0];}
            double speed=currentSpeedKmh; double announceDistance=speed>=80?650:speed>=50?400:speed>=25?220:100;
            String name=step.optString("name", ""); String type=maneuver==null?"":maneuver.optString("type", ""); String modifier=maneuver==null?"":maneuver.optString("modifier", "");
            String instruction=instructionFor(type,modifier,name,maneuver==null?0:maneuver.optInt("exit",0));
            if("arrive".equals(type)&&distanceToManeuver<45){nextInstruction="Arrivo a destinazione";navigating=false;if(!arrivalAnnounced){speak(nextInstruction);arrivalAnnounced=true;lastAnnouncedStepIndex=nextStepIndex;}if("dashboard".equals(currentScreen)&&navInstruction!=null)navInstruction.setText(nextInstruction);if(navigatorStatus!=null&&"navigator".equals(currentScreen))navigatorStatus.setText(nextInstruction);if(navSubLabel!=null)navSubLabel.setText("DESTINAZIONE RAGGIUNTA");return;}
            if(distanceToManeuver<28 && nextStepIndex<routeSteps.length()-1){nextStepIndex++;lastAnnouncedStepIndex=-1;lastAnnouncedStepStage=0;updateNextStep();return;}
            nextInstruction=instruction+(Double.isFinite(distanceToManeuver)?" · "+formatDistance(distanceToManeuver):"");
            if("dashboard".equals(currentScreen)&&navInstruction!=null)navInstruction.setText(nextInstruction);
            if(navSubLabel!=null&&navigating)navSubLabel.setText("NAVIGAZIONE ATTIVA · ARRIVO "+etaLabel());
            if(navigatorStatus!=null&&"navigator".equals(currentScreen))navigatorStatus.setText(nextInstruction+"\nARRIVO "+etaLabel());
            long now=System.currentTimeMillis();
            if(distanceToManeuver<=announceDistance && lastAnnouncedStepIndex!=nextStepIndex){speak("Tra "+formatDistance(distanceToManeuver)+", "+instruction);lastAnnouncedStepIndex=nextStepIndex;lastAnnouncedStepStage=1;lastVoiceAt=now;}else if(distanceToManeuver<=100&&lastAnnouncedStepIndex==nextStepIndex&&lastAnnouncedStepStage<2){speak("Ora, "+instruction);lastAnnouncedStepStage=2;lastVoiceAt=now;}
        } catch (Exception ignored) {}
    }

    private String etaLabel(){
        if(activeRoute==null||routeCoordinates==null||currentLocation==null)return "—";
        try{double total=activeRoute.optDouble("distance",0),duration=activeRoute.optDouble("duration",0);if(total<=0||duration<=0)return "—";int nearestIndex=0;double nearest=Double.MAX_VALUE;
            for(int i=0;i<routeCoordinates.length();i++){JSONArray c=routeCoordinates.optJSONArray(i);if(c==null||c.length()<2)continue;float[] d=new float[1];Location.distanceBetween(currentLocation.getLatitude(),currentLocation.getLongitude(),c.getDouble(1),c.getDouble(0),d);if(d[0]<nearest){nearest=d[0];nearestIndex=i;}}
            double remaining=0;for(int i=nearestIndex;i<routeCoordinates.length()-1;i++){JSONArray a=routeCoordinates.getJSONArray(i),b=routeCoordinates.getJSONArray(i+1);float[] d=new float[1];Location.distanceBetween(a.getDouble(1),a.getDouble(0),b.getDouble(1),b.getDouble(0),d);remaining+=d[0];}
            long eta=System.currentTimeMillis()+(long)(duration*Math.min(1d,remaining/total)*1000d);return new java.text.SimpleDateFormat("HH:mm",Locale.getDefault()).format(new Date(eta));
        }catch(Exception e){return "—";}
    }

    private void checkOffRoute() {
        if(System.currentTimeMillis()-lastOffRouteCheckMs<2000L)return;lastOffRouteCheckMs=System.currentTimeMillis();
        if(!navigating||routeCoordinates==null||currentLocation==null||!Double.isFinite(destinationLat)||!Double.isFinite(destinationLon))return;
        double nearest=Double.MAX_VALUE;
        try{for(int i=0;i<routeCoordinates.length();i++){JSONArray c=routeCoordinates.optJSONArray(i);if(c==null||c.length()<2)continue;float[] d=new float[1];Location.distanceBetween(currentLocation.getLatitude(),currentLocation.getLongitude(),c.getDouble(1),c.getDouble(0),d);if(d[0]<nearest)nearest=d[0];}}catch(Exception ignored){return;}
        if(nearest>110)offRouteCount++;else offRouteCount=0;
        long now=System.currentTimeMillis();
        if(offRouteCount>=3&&now-lastRerouteMs>15000L&&navigatorStatus!=null){offRouteCount=0;lastRerouteMs=now;navigatorStatus.setText("Fuori percorso · ricalcolo…");geocodeAndRoute(String.format(Locale.US,"%.6f,%.6f",destinationLat,destinationLon),navigatorStatus);}
    }

    private String instructionFor(String type, String modifier, String road, int exit) {
        String dir = modifier.contains("left") ? "a sinistra" : modifier.contains("right") ? "a destra" : modifier.contains("straight") ? "prosegui diritto" : "";
        String s;
        if ("roundabout".equals(type) || "rotary".equals(type)) s = exit>0 ? "Alla rotonda, prendi la "+exit+"ª uscita" : "Alla rotonda, segui le indicazioni";
        else if ("arrive".equals(type)) s="Raggiungi la destinazione";
        else if ("depart".equals(type)) s="Parti";
        else if ("merge".equals(type)) s="Immettiti"+(dir.isEmpty()?"":" "+dir);
        else if ("fork".equals(type) || "on ramp".equals(type) || "off ramp".equals(type)) s="Prendi la diramazione"+(dir.isEmpty()?"":" "+dir);
        else if ("turn".equals(type) || "end of road".equals(type) || "continue".equals(type) || "new name".equals(type)) s=dir.isEmpty()?"Prosegui":"Svolta "+dir;
        else s="Prosegui";
        if (road!=null&&!road.trim().isEmpty()&&!("arrive".equals(type))) s+=" su "+road; return s;
    }

    private void showWeather() {
        currentScreen="weather";LinearLayout root=page("METEO");ScrollView scroll=new ScrollView(this);LinearLayout content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(dp(5),dp(5),dp(5),dp(5));
        TextView body=text("Recupero previsioni…",15,primaryText(),false);body.setGravity(Gravity.TOP);body.setPadding(dp(10),dp(10),dp(10),dp(10));body.setBackgroundColor(panelColor());content.addView(body,new LinearLayout.LayoutParams(-1,-2));
        TextView heading=text("PREVISIONI ORARIE · TOCCA UNA FASCIA PER I DETTAGLI",11,accent(),true);heading.setPadding(dp(8),dp(12),dp(8),dp(8));content.addView(heading);LinearLayout hourlyRows=new LinearLayout(this);hourlyRows.setOrientation(LinearLayout.VERTICAL);content.addView(hourlyRows);scroll.addView(content);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));Button back=button("INDIETRO");root.addView(back,new LinearLayout.LayoutParams(-1,dp(48)));back.setOnClickListener(v->showDashboard());setContentView(root);
        if(currentLocation==null){body.setText("Meteo localizzato non disponibile: GPS in attesa.");return;}double lat=currentLocation.getLatitude(),lon=currentLocation.getLongitude();
        new Thread(()->{try{
            String raw=httpGet(String.format(Locale.US,"https://api.open-meteo.com/v1/forecast?latitude=%.4f&longitude=%.4f&current=temperature_2m,apparent_temperature,relative_humidity_2m,precipitation,weather_code,wind_speed_10m,wind_gusts_10m&hourly=temperature_2m,weather_code,precipitation_probability,wind_speed_10m&forecast_days=2&timezone=auto",lat,lon),"NEXT-NAVI-PRO/0.2");
            JSONObject rootJson=new JSONObject(raw),cur=rootJson.getJSONObject("current"),hourly=rootJson.getJSONObject("hourly");
            String currentReport="CONDIZIONI ATTUALI\n"+weatherCodeLabel(cur.optInt("weather_code",-1))+" · "+String.format(Locale.getDefault(),"%.1f °C",cur.optDouble("temperature_2m",Double.NaN))+"\nPercepita: "+String.format(Locale.getDefault(),"%.1f °C",cur.optDouble("apparent_temperature",Double.NaN))+"\nUmidità: "+cur.optInt("relative_humidity_2m",-1)+"%\nVento: "+String.format(Locale.getDefault(),"%.0f km/h · raffiche %.0f km/h",cur.optDouble("wind_speed_10m",Double.NaN),cur.optDouble("wind_gusts_10m",Double.NaN))+"\nPrecipitazioni: "+String.format(Locale.getDefault(),"%.1f mm",cur.optDouble("precipitation",Double.NaN))+"\nAggiornamento: "+cur.optString("time","—");
            JSONArray times=hourly.optJSONArray("time"),temps=hourly.optJSONArray("temperature_2m"),codes=hourly.optJSONArray("weather_code"),prob=hourly.optJSONArray("precipitation_probability"),winds=hourly.optJSONArray("wind_speed_10m");ArrayList<String[]> forecastRows=new ArrayList<>();int first=0;String currentTime=cur.optString("time","");
            if(times!=null){for(int i=0;i<times.length();i++){if(times.optString(i).compareTo(currentTime)>=0){first=i;break;}}for(int i=first;i<Math.min(times.length(),first+24);i++){String hour=times.optString(i);if(hour.length()>=16)hour=hour.substring(11,16);String condition=weatherCodeLabel(codes==null?-1:codes.optInt(i,-1));String temp=temps==null?"—":String.format(Locale.getDefault(),"%.1f",temps.optDouble(i,Double.NaN));String rain=prob==null?"—":Integer.toString(prob.optInt(i,-1));String wind=winds==null?"—":String.format(Locale.getDefault(),"%.0f",winds.optDouble(i,Double.NaN));forecastRows.add(new String[]{hour,condition,temp,rain,wind});}}
            final String report=currentReport;final ArrayList<String[]> rows=forecastRows;
            runOnUiThread(()->{body.setText(report);hourlyRows.removeAllViews();if(rows.isEmpty()){TextView none=text("Previsioni orarie non disponibili.",13,mutedText(),false);hourlyRows.addView(none);return;}for(String[] h:rows){LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(8),dp(7),dp(8),dp(7));card.setBackgroundColor(panelColor());TextView summary=text(h[0]+"  ·  "+h[1]+"  ·  "+h[2]+" °C",13,primaryText(),true);TextView details=text("Probabilità pioggia: "+h[3]+"%\nVento previsto: "+h[4]+" km/h",12,mutedText(),false);details.setVisibility(View.GONE);card.addView(summary);card.addView(details);summary.setOnClickListener(v->details.setVisibility(details.getVisibility()==View.VISIBLE?View.GONE:View.VISIBLE));LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.setMargins(0,dp(2),0,dp(2));hourlyRows.addView(card,cp);}});
        }catch(Exception e){runOnUiThread(()->body.setText("Meteo non disponibile. Controlla la connessione e riprova.\n"+safeMessage(e)));}}).start();
    }
    private String weatherCodeLabel(int code){switch(code){case 0:return "Sereno";case 1:return "Prevalentemente sereno";case 2:return "Parzialmente nuvoloso";case 3:return "Coperto";case 45:case 48:return "Nebbia";case 51:case 53:case 55:return "Pioviggine";case 56:case 57:return "Pioviggine gelata";case 61:case 63:case 65:return "Pioggia";case 66:case 67:return "Pioggia gelata";case 71:case 73:case 75:case 77:return "Neve";case 80:case 81:case 82:return "Rovesci";case 85:case 86:return "Rovesci di neve";case 95:return "Temporale";case 96:case 99:return "Temporale con grandine";default:return "Condizioni non disponibili";}}

    private void showTrips() {
        currentScreen="trips"; LinearLayout root=page("VIAGGI REGISTRATI"); ScrollView scroll=new ScrollView(this); LinearLayout list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); list.setPadding(dp(5),dp(5),dp(5),dp(5));
        try {
            java.util.List<TripDb.TripSummary> trips=tripDb.listTrips(100);
            if(trips.isEmpty()){TextView empty=text("Nessun viaggio registrato. Il diario registra automaticamente gli spostamenti rilevati dal GPS reale.",15,primaryText(),false);empty.setPadding(dp(12),dp(12),dp(12),dp(12));list.addView(empty);}
            for(TripDb.TripSummary trip:trips){
                LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(10),dp(8),dp(10),dp(8));card.setBackgroundColor(panelColor());
                String date=new java.text.SimpleDateFormat("dd/MM/yyyy HH:mm",Locale.getDefault()).format(new Date(trip.startTime));
                String details=date+"\n"+String.format(Locale.getDefault(),"%.1f km · %d min · media %.0f · max %.0f km/h · %d punti",trip.distanceM/1000d,Math.max(1,trip.durationMs/60000),trip.avgKmh,trip.maxKmh,trip.pointCount);
                TextView item=text(details,13,primaryText(),true);card.addView(item);
                LinearLayout actions=new LinearLayout(this);actions.setGravity(Gravity.CENTER);Button export=button("ESPORTA GPX"),delete=button("ELIMINA");actions.addView(export,new LinearLayout.LayoutParams(0,dp(40),1f));actions.addView(delete,new LinearLayout.LayoutParams(0,dp(40),1f));card.addView(actions);
                export.setOnClickListener(v->beginGpxExport(trip.id));delete.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Eliminare il viaggio?").setMessage("Il percorso e tutti i punti GPS saranno eliminati.").setNegativeButton("ANNULLA",null).setPositiveButton("ELIMINA",(d,w)->{tripDb.deleteTrip(trip.id);showTrips();}).show());
                LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.setMargins(0,dp(4),0,dp(4));list.addView(card,cp);
            }
        }catch(Exception e){TextView err=text("Impossibile leggere lo storico dei viaggi.",14,alert(),true);list.addView(err);}
        scroll.addView(list);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));Button back=button("INDIETRO");root.addView(back,new LinearLayout.LayoutParams(-1,dp(46)));back.setOnClickListener(v->showDashboard());setContentView(root);
    }

    private void beginGpxExport(long tripId){
        pendingExportTripId=tripId;Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);intent.addCategory(Intent.CATEGORY_OPENABLE);intent.setType("application/gpx+xml");intent.putExtra(Intent.EXTRA_TITLE,"NEXT_NAVI_PRO_viaggio_"+tripId+".gpx");
        try{startActivityForResult(intent,REQUEST_EXPORT_GPX);}catch(Exception e){Toast.makeText(this,"Esportazione file non disponibile",Toast.LENGTH_LONG).show();}
    }
    private String buildGpx(long tripId)throws Exception{
        List<TripDb.Point> points=tripDb.getPoints(tripId);StringBuilder xml=new StringBuilder(256+points.size()*80);
        xml.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<gpx version=\"1.1\" creator=\"NEXT NAVI PRO\" xmlns=\"http://www.topografix.com/GPX/1/1\">\n<trk><name>NEXT NAVI PRO ").append(tripId).append("</name><trkseg>\n");
        java.text.SimpleDateFormat iso=new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'",Locale.US);iso.setTimeZone(TimeZone.getTimeZone("UTC"));
        for(TripDb.Point point:points){xml.append(String.format(Locale.US,"<trkpt lat=\"%.7f\" lon=\"%.7f\">",point.lat,point.lon));if(Double.isFinite(point.alt))xml.append(String.format(Locale.US,"<ele>%.1f</ele>",point.alt));xml.append("<time>").append(iso.format(new Date(point.time))).append("</time></trkpt>\n");}
        xml.append("</trkseg></trk></gpx>");return xml.toString();
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data);if(requestCode==REQUEST_EXPORT_GPX&&resultCode==RESULT_OK&&data!=null&&data.getData()!=null){Uri uri=data.getData();long id=pendingExportTripId;new Thread(()->{try(OutputStream out=getContentResolver().openOutputStream(uri)){if(out==null)throw new Exception("Destinazione file non disponibile");out.write(buildGpx(id).getBytes(StandardCharsets.UTF_8));runOnUiThread(()->Toast.makeText(this,"GPX esportato correttamente",Toast.LENGTH_LONG).show());}catch(Exception e){runOnUiThread(()->Toast.makeText(this,"Errore esportazione GPX: "+safeMessage(e),Toast.LENGTH_LONG).show());}}).start();}pendingExportTripId=-1L;}

    private void startLocationIfPermitted() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)!=PackageManager.PERMISSION_GRANTED) { requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},REQUEST_LOCATION); return; }
        if(locationCallback!=null) fused.removeLocationUpdates(locationCallback);
        LocationRequest request=new LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY,1000L).setMinUpdateIntervalMillis(500L).build();
        locationCallback=new LocationCallback(){@Override public void onLocationResult(LocationResult result){if(result!=null&&result.getLastLocation()!=null)updateLocation(result.getLastLocation());}};
        try{fused.requestLocationUpdates(request,locationCallback,Looper.getMainLooper());fused.getLastLocation().addOnSuccessListener(this,l->{if(l!=null)updateLocation(l);});}catch(SecurityException e){if(gpsStatus!=null)gpsStatus.setText("PERMESSO GPS NON DISPONIBILE");}
    }

    private void updateLocation(Location location) {
        if(location==null)return; long now=System.currentTimeMillis(); boolean stale=now-location.getTime()>10000L; boolean inaccurate=!location.hasAccuracy()||location.getAccuracy()>50f;
        if(stale||inaccurate){currentSpeedLimitKmh=0;if(gpsStatus!=null){gpsStatus.setText(stale?"GPS OBSOLETO":"GPS INSUFFICIENTE");gpsStatus.setTextColor(alert());}if(speedValue!=null){speedValue.setText("—");speedValue.setTextColor(primaryText());}if(limitValue!=null)limitValue.setText("—");if(limitNote!=null)limitNote.setText(stale?"GPS OBSOLETO":"GPS INSUFFICIENTE");return;}
        currentLocation=new Location(location); currentSpeedKmh=location.hasSpeed()?Math.max(0f,location.getSpeed()*3.6f):0f;
        if(speedValue!=null){speedValue.setText(String.format(Locale.getDefault(),"%.0f",currentSpeedKmh));speedValue.setTextColor(currentSpeedLimitKmh>0&&currentSpeedKmh>currentSpeedLimitKmh+5?alert():primaryText());}if(gpsStatus!=null){gpsStatus.setText(String.format(Locale.getDefault(),"GPS OK · ±%.0f m",location.getAccuracy()));gpsStatus.setTextColor(success());}
        if(tripRecorder!=null)tripRecorder.accept(location); if(navigating){updateNextStep();checkOffRoute();} updateRoadData(location);
        if("navigator".equals(currentScreen)&&mapLibreMap!=null){LatLng here=new LatLng(location.getLatitude(),location.getLongitude());if(currentPositionMarker!=null)currentPositionMarker.setPosition(here);else currentPositionMarker=mapLibreMap.addMarker(new MarkerOptions().position(here).title("Posizione GPS"));float bearing=location.hasBearing()?location.getBearing():0;long cameraNow=System.currentTimeMillis();boolean moved=lastCameraLocation==null||lastCameraLocation.distanceTo(location)>=5f;boolean turned=Float.isNaN(lastCameraBearing)||Math.abs(((bearing-lastCameraBearing+540f)%360f)-180f)>=8f;if(cameraNow-lastCameraUpdateMs>=650L&&(moved||turned)){CameraPosition cp=new CameraPosition.Builder().target(here).zoom(15).bearing(bearing).build();mapLibreMap.animateCamera(org.maplibre.android.camera.CameraUpdateFactory.newCameraPosition(cp),600);lastCameraLocation=new Location(location);lastCameraBearing=bearing;lastCameraUpdateMs=cameraNow;}}
    }

    /** Road data and limit matching run off the UI thread; cache persists in SQLite. */
    private void updateRoadData(Location location) {
        if(location==null||!location.hasAccuracy()||location.getAccuracy()>35f||roadEngine==null)return;
        latestRoadLocation=new Location(location);
        if(!roadTaskQueued.compareAndSet(false,true))return;
        roadExecutor.execute(()->{
            int limit=0;String note="DATI STRADALI NON DISPONIBILI";Location processed=null;
            try{
                Location l=latestRoadLocation;if(l==null)return;processed=new Location(l);long now=System.currentTimeMillis();
                if(roadEngine.lastRoadQueryLocation==null)roadEngine.reloadRoads(l);
                boolean cacheEmpty=roadEngine.mapWays==null||roadEngine.mapWays.isEmpty();
                boolean moved=lastRoadFetchLocation==null||lastRoadFetchLocation.distanceTo(l)>=8000f;
                boolean expired=now-lastRoadFetchAt>=6L*60L*60L*1000L;
                boolean retryEmptyCache=cacheEmpty&&(lastRoadFetchAt==0L||now-lastRoadFetchAt>=120000L);
                boolean refreshMoved=!cacheEmpty&&moved;
                if(retryEmptyCache||refreshMoved||expired){
                    boolean loaded=roadEngine.fetchOnline(l);lastRoadFetchAt=now;lastRoadFetchLocation=new Location(l);
                    getSharedPreferences(PREFS,MODE_PRIVATE).edit().putLong("roads_last_fetch",now).putString("roads_last_location",l.getLatitude()+","+l.getLongitude()).apply();
                    roadEngine.reloadRoads(l);note=loaded?"DATI OSM AGGIORNATI":"CACHE STRADALE PARZIALE";
                }
                roadEngine.update(l);limit=roadEngine.speedLimitKmh(l);
                Curve curve=null; JSONArray routeSnapshot=routeCoordinates; if(navigating&&routeSnapshot!=null){ArrayList<RoutePoint> pts=new ArrayList<>();for(int i=0;i<routeSnapshot.length();i++){JSONArray c=routeSnapshot.optJSONArray(i);if(c!=null&&c.length()>=2)pts.add(new RoutePoint(c.optDouble(1),c.optDouble(0)));}curve=roadEngine.findCurveOnRoute(l,pts);}else curve=roadEngine.findCurve(l,roadEngine.ways);curve=roadEngine.stabilizeCurve(curve); final Curve curveResult=curve; runOnUiThread(()->updateCurveDisplay(curveResult));
                if(limit>0)note="OSM · VERIFICARE SEGNALETICA";else if(roadEngine.mapWays!=null&&!roadEngine.mapWays.isEmpty())note="LIMITE NON DISPONIBILE";
                final int matchedLimit=limit;final String finalNote=note;final Location resultLocation=processed;
                runOnUiThread(()->{currentSpeedLimitKmh=matchedLimit;if(!"dashboard".equals(currentScreen)||limitValue==null)return;if(latestRoadLocation!=null&&latestRoadLocation.distanceTo(resultLocation)>200f)return;limitValue.setText(matchedLimit>0?Integer.toString(matchedLimit):"—");if(limitNote!=null)limitNote.setText(finalNote);if(speedValue!=null)speedValue.setTextColor(matchedLimit>0&&currentSpeedKmh>matchedLimit+5?alert():primaryText());});
            }catch(Exception ignored){}finally{roadTaskQueued.set(false);}
        });
    }

    private void updateCurveDisplay(Curve curve){
        boolean drivingScreen="dashboard".equals(currentScreen)||"navigator".equals(currentScreen);
        if(curve==null||!curve.valid||curve.confidence<0.62f||curve.distance<8f||curve.distance>700f){
            if(curveWarningLabel!=null&&"dashboard".equals(currentScreen)){curveWarningLabel.setText("NESSUNA CURVA AFFIDABILE RILEVATA");curveWarningLabel.setTextColor(mutedText());}
            if(curve==null||!curve.valid||curve.distance<8f)lastCurveAlertKey="";return;
        }
        String direction=curve.dir<0?"SINISTRA":"DESTRA";String kind=curve.type>=4?"TORNANTE":curve.type==3?"CURVA STRETTA":curve.type==2?"CURVA MEDIA":"CURVA LEGGERA";
        String recommendation=curve.recommended>0?" · "+Math.round(curve.recommended)+" km/h consigliati":"";
        if(curveWarningLabel!=null&&"dashboard".equals(currentScreen)){curveWarningLabel.setText(kind+" "+direction+" · "+Math.round(curve.distance)+" m"+recommendation);curveWarningLabel.setTextColor(curve.type>=3?alert():accent());}
        String key=curve.roadId+":"+curve.type+":"+curve.dir;
        if(drivingScreen&&curve.distance<=400f&&curve.distance>=25f&&!key.equals(lastCurveAlertKey)&&System.currentTimeMillis()-lastCurveBeepAt>5000L){lastCurveAlertKey=key;lastCurveBeepAt=System.currentTimeMillis();playCurveBeep(curve.type>=4?3:curve.type>=2?2:1);}
    }
    private void playCurveBeep(int count){if(toneGenerator==null||!getSharedPreferences(PREFS,MODE_PRIVATE).getBoolean("curve_sound_enabled",true))return;for(int i=0;i<count;i++){final int delay=i*260;audioHandler.postDelayed(()->{if(toneGenerator!=null)toneGenerator.startTone(ToneGenerator.TONE_PROP_BEEP,110);},delay);}}

    private String httpGet(String address,String userAgent)throws Exception{HttpURLConnection c=(HttpURLConnection)new URL(address).openConnection();c.setRequestMethod("GET");c.setConnectTimeout(10000);c.setReadTimeout(15000);c.setRequestProperty("User-Agent",userAgent);c.setRequestProperty("Accept","application/json");int code=c.getResponseCode();InputStream stream=code>=200&&code<300?c.getInputStream():c.getErrorStream();if(stream==null)throw new Exception("HTTP "+code);BufferedReader r=new BufferedReader(new InputStreamReader(stream,StandardCharsets.UTF_8));StringBuilder b=new StringBuilder();String line;while((line=r.readLine())!=null)b.append(line);r.close();c.disconnect();if(code<200||code>=300)throw new Exception("Servizio remoto HTTP "+code);return b.toString();}
    private void speak(String s){if(getSharedPreferences(PREFS,MODE_PRIVATE).getBoolean("voice_enabled",true)&&tts!=null&&s!=null&&!s.isEmpty())tts.speak(s,TextToSpeech.QUEUE_FLUSH,null,"nextnavi-"+System.currentTimeMillis());}
    private String formatDistance(double meters){return meters>=1000?String.format(Locale.getDefault(),"%.1f km",meters/1000):String.format(Locale.getDefault(),"%.0f m",meters);}
    private String formatDuration(double seconds){long mins=Math.max(1,Math.round(seconds/60));return mins>=60?(mins/60)+" h "+(mins%60)+" min":mins+" min";}
    private String safeMessage(Exception e){String m=e.getMessage();return m==null?"servizio non disponibile":m;}
    private LinearLayout page(String heading){applySystemBars();LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(12),dp(8),dp(12),dp(8));root.setBackgroundColor(bg());TextView t=text(heading,20,accent(),true);t.setGravity(Gravity.CENTER);root.addView(t,new LinearLayout.LayoutParams(-1,dp(48)));return root;}
    private LinearLayout panel(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setBackgroundColor(panelColor());l.setGravity(Gravity.CENTER);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-1);p.setMargins(dp(3),dp(3),dp(3),dp(3));l.setLayoutParams(p);return l;}
    private TextView text(String value,float size,int color,boolean bold){TextView t=new TextView(this);t.setText(value);t.setTextColor(color);t.setTextSize(size);t.setGravity(Gravity.CENTER_VERTICAL);t.setTypeface(Typeface.create("sans-serif",bold?Typeface.BOLD:Typeface.NORMAL));t.setIncludeFontPadding(false);return t;}
    private Button button(String label){Button b=new Button(this);b.setText(label);b.setTextColor(negativeTheme?Color.WHITE:Color.rgb(5,10,18));b.setTextSize(9);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);b.setAllCaps(false);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(accent()));b.setPadding(dp(1),0,dp(1),0);return b;}
    private void addSpace(LinearLayout p,int h){View v=new View(this);p.addView(v,new LinearLayout.LayoutParams(1,dp(h)));}
    private int dp(float v){return(int)(v*getResources().getDisplayMetrics().density+.5f);}

    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grantResults){super.onRequestPermissionsResult(requestCode,permissions,grantResults);if(requestCode==REQUEST_LOCATION){boolean granted=false;for(int r:grantResults)if(r==PackageManager.PERMISSION_GRANTED)granted=true;if(granted)startLocationIfPermitted();else if(gpsStatus!=null){gpsStatus.setText("AUTORIZZA IL GPS PER LEGGERE LA VELOCITÀ");gpsStatus.setTextColor(alert());}}}
    @Override public void onConfigurationChanged(Configuration c){super.onConfigurationChanged(c);if("dashboard".equals(currentScreen))showDashboard();else if("navigator".equals(currentScreen))showNavigator();}
    private void disposeMapView(){if(mapView!=null){try{mapView.onPause();mapView.onStop();mapView.onDestroy();}catch(Exception ignored){}mapView=null;mapLibreMap=null;currentPositionMarker=null;destinationMarker=null;lastCameraLocation=null;lastCameraBearing=Float.NaN;}}
    @Override protected void onStart(){super.onStart();if(mapView!=null)mapView.onStart();}
    @Override protected void onStop(){if(mapView!=null)mapView.onStop();super.onStop();}
    @Override protected void onPause(){if(mapView!=null)mapView.onPause();if(fused!=null&&locationCallback!=null)fused.removeLocationUpdates(locationCallback);if(brightnessCaptured){WindowManager.LayoutParams lp=getWindow().getAttributes();lp.screenBrightness=originalWindowBrightness;getWindow().setAttributes(lp);}super.onPause();}
    @Override protected void onResume(){super.onResume();if(mapView!=null)mapView.onResume();if("dashboard".equals(currentScreen)||"navigator".equals(currentScreen))startLocationIfPermitted();}
    @Override protected void onDestroy(){disposeMapView();if(fused!=null&&locationCallback!=null)fused.removeLocationUpdates(locationCallback);if(tts!=null){tts.stop();tts.shutdown();}if(toneGenerator!=null){toneGenerator.release();toneGenerator=null;}audioHandler.removeCallbacksAndMessages(null);roadExecutor.shutdownNow();if(roadDb!=null)roadDb.close();if(tripRecorder!=null)tripRecorder.shutdown();if(tripDb!=null)tripDb.close();super.onDestroy();}
    @Override public void onLowMemory(){super.onLowMemory();if(mapView!=null)mapView.onLowMemory();}
    @Override public void onBackPressed(){if(!"dashboard".equals(currentScreen))showDashboard();else super.onBackPressed();}
}
